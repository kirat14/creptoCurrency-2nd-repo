<!DOCTYPE html PUBLIC>
<html xmlns="https://www.w3.org/1999/xhtml">

<head>

</head>

<body>
    <ul>
        <?php echo $email_content;?>
    </ul>

</body>

</html>